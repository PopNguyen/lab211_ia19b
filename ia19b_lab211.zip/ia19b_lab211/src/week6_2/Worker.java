/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package week6_2;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ASUS
 */
public class Worker {

    private String id;  
    private String name;
    private int age;
    private double salary;
    private String workLocation;
    List<Salary> salaryHistory;

    public Worker(String id, String name, int age, String workLocation, List<Salary> salaryHistory) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.workLocation = workLocation;
        this.salaryHistory = salaryHistory;
    }
    
    
    public String getId() {
        return id;
    }
    
    
    public void addSalaryHistory(Salary salary){
        salaryHistory.add(salary);
    }

    public List<Salary> getSalaryHistory() {
        return salaryHistory;
    }

    public void setSalaryHistory(List<Salary> salaryHistory) {
        this.salaryHistory = salaryHistory;
    }

    @Override
    public String toString() {
        return "id=" + id + ", name=" + name + ", age=" + age ;
    }

   

   
    
    
    
}
