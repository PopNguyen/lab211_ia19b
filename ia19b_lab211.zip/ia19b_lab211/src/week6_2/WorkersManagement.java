/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package week6_2;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ASUS
 */
public class WorkersManagement {

    List<Worker> listWorkers = new ArrayList<>();

    public WorkersManagement() {

    }

    public boolean checkID(Worker worker) {

        return false;

    }

    public boolean checkAge(Worker worker) {

        return false;

    }

    public boolean checkSalary(Worker worker) {

        return false;

    }

    public void addWorker(Worker worker) {
//        if (checkID(worker) && checkAge(worker) && checkSalary(worker)) {
            listWorkers.add(worker);
//            return true;
//        }
//        return false;

    }

    public void show() {
        for (Worker n : listWorkers) {
            String tem = n.toString();
            for (Salary s : n.getSalaryHistory()) {
                System.out.println(tem + " " + s);
            }
        }

    }

   public boolean changeSalary(String status,String id, double amount){
       for(Worker w:listWorkers){
           if(w.getId().equalsIgnoreCase(id)){
               w.addSalaryHistory(new Salary(amount, status, LocalDate.now().toString()));
               return true;
           }
       }
       return false;
   }

}
