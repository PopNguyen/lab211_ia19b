/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package week6_2;

import static java.lang.System.exit;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class Main {

    public static void main(String[] args) {
        menu();
    }

    static void menu() {
        Scanner sc = new Scanner(System.in);
        WorkersManagement wMg = new WorkersManagement();
        while (true) {
            System.out.println("""
                               1. Add a Worker.
                               2. Increase salary for worker.
                               3. Decrease for worker.
                               4. Show adjusted salary worker information.
                               5. Exit
                               Please enter your choice:
                               """);
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("------------ Add Worker ------------");
                    ArrayList<Salary> s1 = new ArrayList<>();
                    s1.add(new Salary(2000000, "begin", LocalDate.now().toString()));
                    wMg.addWorker(new Worker("w1", "Thinh", 20, "Ha Noi", s1));
                    break;
                case 2:
                    wMg.changeSalary("UP", "w1", 400000);
                    break;
                case 3:
                    wMg.changeSalary("DOWN", "w1", 200000);
                    break;
                case 4:
                    wMg.show();
                    break;
                case 5:
                    exit(0);
            }
        }

    }

}
